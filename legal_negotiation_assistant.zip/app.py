"""
Legal Negotiation Assistant - Main Streamlit Application Entry Point.
Production-ready educational AI web application for contract risk analysis, plain English translation,
negotiation recommendations, RAG Q&A chat, contract diffing, and PDF report export.
"""

import os
import sys

# Ensure project directory is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st
import pandas as pd



# Page Configuration - Must be first Streamlit command
st.set_page_config(
    page_title="Legal Negotiation Assistant",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

from utils.disclaimers import LEGAL_DISCLAIMER_TEXT, SHORT_DISCLAIMER
from utils.helpers import (
    inject_custom_css, render_metric_card, render_risk_pie_chart, render_clause_category_bar_chart
)
from database.db_manager import (
    init_db, get_user_documents, save_document, save_analysis,
    get_document_by_id, get_all_users, delete_user, get_all_documents, delete_document,
    save_chat_message, get_chat_history
)
from backend.auth import register_user, authenticate_user
from backend.document_parser import parse_document
from backend.clause_analyzer import analyze_document_clauses
from backend.negotiation_engine import get_clause_negotiation_package
from backend.comparator import compare_documents
from backend.report_generator import generate_pdf_report
from models.embeddings import search_engine
from models.llm_handler import LLMHandler
from export_project_zip import create_project_zip

# Initialize DB on launch
init_db()

# Inject Custom CSS
inject_custom_css()

# Session State Initialization
if "user" not in st.session_state:
    st.session_state["user"] = None
if "current_doc" not in st.session_state:
    st.session_state["current_doc"] = None
if "theme" not in st.session_state:
    st.session_state["theme"] = "Dark"


def render_sidebar():
    """Render application sidebar with auth, navigation, and settings."""
    st.sidebar.markdown("<h2 style='text-align: center; color: #3B82F6;'>⚖️ Legal Assistant</h2>", unsafe_allow_html=True)
    st.sidebar.markdown(f"<p style='text-align: center; font-size: 0.8rem; color: #94A3B8;'>{SHORT_DISCLAIMER}</p>", unsafe_allow_html=True)
    st.sidebar.markdown("---")

    if not st.session_state["user"]:
        auth_mode = st.sidebar.radio("Account Access", ["Login", "Register"])
        st.sidebar.markdown("---")

        if auth_mode == "Login":
            st.sidebar.subheader("User Login")
            username = st.sidebar.text_input("Username", key="login_user")
            password = st.sidebar.text_input("Password", type="password", key="login_pwd")

            if st.sidebar.button("Log In", use_container_width=True):
                user, msg = authenticate_user(username, password)
                if user:
                    st.session_state["user"] = user
                    st.sidebar.success(msg)
                    st.rerun()
                else:
                    st.sidebar.error(msg)

        else:
            st.sidebar.subheader("New User Registration")
            new_username = st.sidebar.text_input("Username", key="reg_user")
            new_email = st.sidebar.text_input("Email Address", key="reg_email")
            new_password = st.sidebar.text_input("Password", type="password", key="reg_pwd")

            if st.sidebar.button("Register Account", use_container_width=True):
                success, msg = register_user(new_username, new_email, new_password)
                if success:
                    st.sidebar.success(msg)
                    st.sidebar.info("You can now log in with your credentials.")
                else:
                    st.sidebar.error(msg)

        return "Auth"

    else:
        user = st.session_state["user"]
        st.sidebar.markdown(f"👤 **Logged in as:** `{user['username']}` ({user['role'].upper()})")

        # Sidebar AI Model Provider Configuration
        st.sidebar.markdown("---")
        st.sidebar.subheader("🤖 AI Settings")
        ai_provider = st.sidebar.selectbox("LLM Provider", ["Local NLP Engine", "OpenAI API", "Ollama (Local LLM)"])
        api_key = ""
        if ai_provider == "OpenAI API":
            api_key = st.sidebar.text_input("OpenAI API Key", type="password")

        st.session_state["llm_handler"] = LLMHandler(provider=ai_provider, api_key=api_key)

        st.sidebar.markdown("---")

        # Navigation Options
        nav_options = [
            "📊 Dashboard",
            "📤 Upload Document",
            "🔍 AI Clause Analysis",
            "🤝 Negotiation Assistant",
            "💬 AI Chat Assistant",
            "🔎 Clause Search",
            "⚖️ Contract Comparison",
            "📥 Export Reports"
        ]
        if user["role"] == "admin":
            nav_options.append("⚙️ Admin Panel")

        selected_nav = st.sidebar.radio("Navigation Menu", nav_options)

        st.sidebar.markdown("---")

        # Download ZIP Button
        if st.sidebar.button("📦 Download Project ZIP", use_container_width=True):
            zip_path = create_project_zip()
            with open(zip_path, "rb") as f:
                st.sidebar.download_button(
                    label="⬇️ Click to Download ZIP",
                    data=f.read(),
                    file_name="legal_negotiation_assistant.zip",
                    mime="application/zip",
                    use_container_width=True
                )

        if st.sidebar.button("Logout", use_container_width=True):
            st.session_state["user"] = None
            st.session_state["current_doc"] = None
            st.rerun()

        return selected_nav


def main():
    """Main application layout router."""
    selected_nav = render_sidebar()

    # Show disclaimer banner at top
    st.info("⚠️ **EDUCATIONAL TOOL DISCLAIMER**: This application is strictly for educational purposes and does not constitute formal legal advice. Always consult a licensed attorney before signing contracts.")

    if not st.session_state["user"]:
        st.markdown("<h1 class='main-header'>Welcome to Legal Negotiation Assistant</h1>", unsafe_allow_html=True)
        st.markdown("<p class='sub-header'>Understand legal documents, flag risky clauses, translate legalese into plain English, and prepare neutral negotiation points.</p>", unsafe_allow_html=True)

        col1, col2, col3 = st.columns(3)
        with col1:
            render_metric_card("11 Clause Types", "Supported", "📜")
        with col2:
            render_metric_card("OCR & Multi-Format", "PDF / DOCX / Img", "🔍")
        with col3:
            render_metric_card("100% Offline Capable", "Zero Cost", "⚡")

        st.markdown("### Please Log In or Register using the sidebar menu to begin.")
        st.markdown(LEGAL_DISCLAIMER_TEXT)
        return

    user = st.session_state["user"]

    # 1. DASHBOARD
    if "Dashboard" in selected_nav:
        st.markdown("<h1 class='main-header'>📊 User Dashboard</h1>", unsafe_allow_html=True)
        st.markdown(f"Welcome back, **{user['username']}**! Here is an overview of your contract analysis history.")

        user_docs = get_user_documents(user["id"])

        c1, c2, c3, c4 = st.columns(4)
        with c1:
            render_metric_card("Total Documents", str(len(user_docs)), "📁")
        with c2:
            avg_risk = round(sum(d["overall_risk_score"] for d in user_docs) / len(user_docs), 1) if user_docs else 0.0
            render_metric_card("Avg Risk Score", f"{avg_risk}/100", "⚠️")
        with c3:
            total_clauses = sum(d["clause_count"] for d in user_docs)
            render_metric_card("Clauses Flagged", str(total_clauses), "📌")
        with c4:
            render_metric_card("User Role", user["role"].upper(), "🛡️")

        st.markdown("---")

        if user_docs:
            col_left, col_right = st.columns([1, 1])

            with col_left:
                st.subheader("Document History")
                doc_df = pd.DataFrame(user_docs)[["id", "filename", "file_type", "clause_count", "overall_risk_score", "upload_time"]]
                doc_df.columns = ["ID", "Filename", "Type", "Clauses", "Risk Score", "Uploaded"]
                st.dataframe(doc_df, use_container_width=True)

                selected_doc_id = st.selectbox("Select document to inspect:", [d["id"] for d in user_docs], format_func=lambda x: f"Doc #{x} - {next(d['filename'] for d in user_docs if d['id']==x)}")
                if st.button("Load Selected Document"):
                    st.session_state["current_doc"] = get_document_by_id(selected_doc_id)
                    st.success(f"Loaded document #{selected_doc_id}")
                    st.rerun()

            with col_right:
                st.subheader("Risk Analytics")
                if st.session_state["current_doc"]:
                    doc = st.session_state["current_doc"]
                    render_risk_pie_chart(doc.get("risk_breakdown", {}))
                else:
                    st.info("Select a document from the left to view specific risk analytics.")
        else:
            st.info("No documents uploaded yet. Go to the **Upload Document** tab to upload your first contract.")

    # 2. UPLOAD DOCUMENT
    elif "Upload" in selected_nav:
        st.markdown("<h1 class='main-header'>📤 Upload & Extract Document</h1>", unsafe_allow_html=True)
        st.markdown("Upload legal agreements in **PDF**, **DOCX**, **TXT**, or **Scanned Image (JPG/PNG)** format.")

        uploaded_file = st.file_uploader("Choose a contract file", type=["pdf", "docx", "doc", "txt", "jpg", "jpeg", "png"])

        if uploaded_file:
            st.success(f"File selected: `{uploaded_file.name}` ({uploaded_file.size} bytes)")

            if st.button("🚀 Analyze Contract Now"):
                with st.spinner("Parsing text, running OCR, extracting clauses, and assessing risks..."):
                    file_bytes = uploaded_file.read()
                    extracted_text, file_type = parse_document(uploaded_file.name, file_bytes)

                    if extracted_text.startswith("[Error"):
                        st.error(extracted_text)
                    else:
                        clauses, risk_breakdown, summary, overall_score = analyze_document_clauses(extracted_text)

                        # Save to Database
                        doc_id = save_document(
                            user_id=user["id"],
                            filename=uploaded_file.name,
                            file_type=file_type,
                            extracted_text=extracted_text,
                            clause_count=len(clauses),
                            risk_score=overall_score
                        )
                        save_analysis(doc_id, summary, clauses, risk_breakdown)

                        # Set in Session State
                        st.session_state["current_doc"] = get_document_by_id(doc_id)

                        st.balloons()
                        st.success(f"Analysis Complete! Contract saved as Document #{doc_id}.")
                        st.markdown(f"**Overall Risk Score**: `{overall_score} / 100`")

        # Sample Document Direct Load Option
        st.markdown("---")
        st.subheader("💡 Or test instantly with sample contracts:")
        col_s1, col_s2, col_s3, col_s4 = st.columns(4)

        sample_files = {
            "Employment (Strict)": "sample_docs/sample_employment_agreement.txt",
            "Employment (Revised)": "sample_docs/sample_revised_employment_agreement.txt",
            "Vendor Agreement": "sample_docs/sample_vendor_contract.txt",
            "SaaS License": "sample_docs/sample_software_license_agreement.txt"
        }

        for idx, (label, s_path) in enumerate(sample_files.items()):
            col = [col_s1, col_s2, col_s3, col_s4][idx]
            if col.button(f"Load {label}"):
                if os.path.exists(s_path):
                    with open(s_path, "r", encoding="utf-8") as f:
                        text = f.read()
                    clauses, risk_breakdown, summary, overall_score = analyze_document_clauses(text)
                    doc_id = save_document(user["id"], os.path.basename(s_path), "TXT", text, len(clauses), overall_score)
                    save_analysis(doc_id, summary, clauses, risk_breakdown)
                    st.session_state["current_doc"] = get_document_by_id(doc_id)
                    st.success(f"Loaded {label}!")
                    st.rerun()


    # 3. AI CLAUSE ANALYSIS
    elif "Clause Analysis" in selected_nav:
        st.markdown("<h1 class='main-header'>🔍 AI Clause Analysis & Risk Breakdown</h1>", unsafe_allow_html=True)

        if not st.session_state["current_doc"]:
            st.warning("Please upload or select a document first from the Upload or Dashboard tab.")
            return

        doc = st.session_state["current_doc"]
        st.subheader(f"Document: {doc['filename']} (Risk Score: {doc['overall_risk_score']}/100)")

        st.markdown("#### Executive Summary")
        st.info(doc.get("summary", "No summary available."))

        st.markdown("---")
        st.subheader(f"Flagged Clauses ({len(doc.get('clauses', []))})")

        risk_filter = st.multiselect("Filter by Risk Level", ["High", "Medium", "Low"], default=["High", "Medium", "Low"])

        for c in doc.get("clauses", []):
            if c.get("risk_level") in risk_filter:
                risk_lvl = c.get("risk_level")
                badge_class = f"badge-{risk_lvl.lower()}"
                card_class = f"clause-card-{risk_lvl.lower()}"

                st.markdown(f"""
                <div class="clause-card {card_class}">
                    <div style="display:flex; justify-between; align-items:center;">
                        <span style="font-weight:bold; font-size:1.1rem;">Clause #{c.get('id')} - {c.get('category')}</span>
                        <span class="{badge_class}">{risk_lvl} Risk ({c.get('risk_score')}/100)</span>
                    </div>
                    <p style="margin-top:0.5rem; font-style:italic;">"{c.get('text')}"</p>
                    <p><b>Reason:</b> {c.get('reason')}</p>
                    <p><b>Consequences:</b> {c.get('consequences')}</p>
                </div>
                """, unsafe_allow_html=True)

                with st.expander("Key Points to Understand Before Signing"):
                    for pt in c.get("understand_points", []):
                        st.write(f"• {pt}")

    # 4. NEGOTIATION ASSISTANT
    elif "Negotiation Assistant" in selected_nav:
        st.markdown("<h1 class='main-header'>🤝 Negotiation Battlecards</h1>", unsafe_allow_html=True)
        st.markdown("Plain English translations, neutral questions to ask counterparties, and alternative counter-clause proposals.")

        if not st.session_state["current_doc"]:
            st.warning("Please upload or select a document first.")
            return

        doc = st.session_state["current_doc"]
        clauses = doc.get("clauses", [])

        if not clauses:
            st.info("No clauses available for negotiation.")
            return

        selected_clause_id = st.selectbox("Select Clause to Prepare Negotiation Strategy:", [c["id"] for c in clauses], format_func=lambda x: f"Clause #{x} - {next(c['category'] for c in clauses if c['id']==x)}")

        target_clause = next(c for c in clauses if c["id"] == selected_clause_id)
        package = get_clause_negotiation_package(target_clause)

        col_a, col_b = st.columns([1, 1])

        with col_a:
            st.markdown("### 📜 Original Legal Clause")
            st.code(package["original_text"], language="text")

            st.markdown("### 💡 Plain English Translation")
            st.info(package["plain_english"])

        with col_b:
            st.markdown("### 💬 Neutral Questions to Ask Counterparty")
            for q in package["questions"]:
                st.write(f"❓ {q}")

            st.markdown("### 📝 Example Alternative Counter-Wording")
            st.success(package["alternative_wording"])

        st.caption(package["disclaimer"])

    # 5. AI CHAT ASSISTANT
    elif "Chat" in selected_nav:
        st.markdown("<h1 class='main-header'>💬 AI Document Q&A Chat</h1>", unsafe_allow_html=True)
        st.markdown("Ask any question about your contract. The AI uses document context to answer.")

        if not st.session_state["current_doc"]:
            st.warning("Please upload or select a document first.")
            return

        doc = st.session_state["current_doc"]
        chat_history = get_chat_history(doc["id"], user["id"])

        for msg in chat_history:
            with st.chat_message(msg["role"]):
                st.write(msg["message"])

        user_query = st.chat_input("Ask a question about this contract (e.g., 'What are the main risks?'):")

        if user_query:
            # Render user message
            with st.chat_message("user"):
                st.write(user_query)
            save_chat_message(doc["id"], user["id"], "user", user_query)

            # Generate AI Response
            handler = st.session_state.get("llm_handler", LLMHandler())
            response = handler.ask_contract_question(user_query, doc["extracted_text"], doc["clauses"])

            with st.chat_message("assistant"):
                st.write(response)
            save_chat_message(doc["id"], user["id"], "assistant", response)

    # 6. CLAUSE SEARCH
    elif "Clause Search" in selected_nav:
        st.markdown("<h1 class='main-header'>🔎 Semantic & Keyword Clause Search</h1>", unsafe_allow_html=True)

        if not st.session_state["current_doc"]:
            st.warning("Please upload or select a document first.")
            return

        doc = st.session_state["current_doc"]
        search_query = st.text_input("Enter legal term or query (e.g. 'non-compete', 'indemnify', 'termination notice'):")

        if search_query:
            results = search_engine.search_similar_clauses(search_query, doc["clauses"], top_k=5)
            st.markdown(f"Found **{len(results)}** matching clauses:")

            for res in results:
                st.markdown(f"**Clause #{res['id']} - {res['category']}** (Risk: `{res['risk_level']}`) | Similarity: `{round(res.get('similarity_score', 0)*100, 1)}%`")
                st.write(f"\"{res['text']}\"")
                st.markdown("---")

    # 7. CONTRACT COMPARISON
    elif "Comparison" in selected_nav:
        st.markdown("<h1 class='main-header'>⚖️ Contract Comparison & Diff Tool</h1>", unsafe_allow_html=True)
        st.markdown("Upload two contract versions (e.g., Original vs Revised Counter-Offer) to detect added, removed, or modified terms.")

        col_v1, col_v2 = st.columns(2)
        with col_v1:
            file_a = st.file_uploader("Upload Original Contract (Version A)", type=["txt", "pdf", "docx"], key="file_a")
        with col_v2:
            file_b = st.file_uploader("Upload Revised Contract (Version B)", type=["txt", "pdf", "docx"], key="file_b")

        if file_a and file_b:
            if st.button("🔍 Compare Versions Now"):
                text_a, _ = parse_document(file_a.name, file_a.read())
                text_b, _ = parse_document(file_b.name, file_b.read())

                comp_res = compare_documents(text_a, text_b)
                st.success("Comparison Complete!")
                st.info(comp_res["summary"])

                t1, t2, t3 = st.tabs(["Modified Clauses", "Added Clauses", "Removed Clauses"])

                with t1:
                    for mod in comp_res["modified"]:
                        st.markdown("**Original Version:**")
                        st.error(mod["original"])
                        st.markdown("**Revised Version:**")
                        st.success(mod["revised"])
                        st.markdown("---")

                with t2:
                    for add in comp_res["added"]:
                        st.success(f"➕ Added: {add}")

                with t3:
                    for rem in comp_res["removed"]:
                        st.error(f"➖ Removed: {rem}")

    # 8. EXPORT REPORTS
    elif "Export" in selected_nav:
        st.markdown("<h1 class='main-header'>📥 Export Audit Reports</h1>", unsafe_allow_html=True)

        if not st.session_state["current_doc"]:
            st.warning("Please upload or select a document first.")
            return

        doc = st.session_state["current_doc"]

        st.subheader(f"Exporting Report for: {doc['filename']}")
        report_type = st.selectbox("Report Type", ["Full Audit Report (PDF)", "Negotiation Battlecard (PDF)"])

        if st.button("📄 Generate PDF Report"):
            pdf_bytes = generate_pdf_report(doc, report_type="FULL")

            st.download_button(
                label="⬇️ Download PDF Report",
                data=pdf_bytes,
                file_name=f"{os.path.splitext(doc['filename'])[0]}_Audit_Report.pdf",
                mime="application/pdf"
            )

    # 9. ADMIN PANEL
    elif "Admin Panel" in selected_nav and user["role"] == "admin":
        st.markdown("<h1 class='main-header'>⚙️ System Admin Panel</h1>", unsafe_allow_html=True)

        admin_tab1, admin_tab2 = st.tabs(["Manage Users", "Manage System Documents"])

        with admin_tab1:
            st.subheader("Registered Users")
            users = get_all_users()
            st.dataframe(pd.DataFrame(users), use_container_width=True)

            del_user_id = st.number_input("Enter User ID to Delete", min_value=1, step=1)
            if st.button("Delete User Account"):
                if delete_user(del_user_id):
                    st.success(f"User #{del_user_id} deleted successfully.")
                    st.rerun()

        with admin_tab2:
            st.subheader("System Uploaded Documents")
            docs = get_all_documents()
            st.dataframe(pd.DataFrame(docs)[["id", "username", "filename", "file_type", "clause_count", "overall_risk_score", "upload_time"]], use_container_width=True)

            del_doc_id = st.number_input("Enter Document ID to Delete", min_value=1, step=1, key="del_doc")
            if st.button("Delete Document Entry"):
                if delete_document(del_doc_id):
                    st.success(f"Document #{del_doc_id} deleted successfully.")
                    st.rerun()


if __name__ == "__main__":
    main()
