"""
OCR Engine module for extracting text from images and scanned document pages.
Supports EasyOCR, PyTesseract, and PIL-based image preprocessing with graceful fallbacks.
"""

import os
from PIL import Image, ImageEnhance, ImageFilter

# Check available OCR libraries
EASYOCR_AVAILABLE = False
TESSERACT_AVAILABLE = False

try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    pass

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    pass


def preprocess_image(image: Image.Image) -> Image.Image:
    """Preprocess image to improve OCR accuracy (grayscale, contrast, sharpness)."""
    # Convert to grayscale
    img = image.convert('L')
    # Enhance contrast
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(1.8)
    # Sharpen image
    img = img.filter(ImageFilter.SHARPEN)
    return img


def extract_text_from_image(image_input) -> str:
    """
    Extract text from an image file path or PIL Image object using EasyOCR or Tesseract.
    Falls back gracefully if libraries are missing.
    """
    if isinstance(image_input, str):
        if not os.path.exists(image_input):
            return "[Error: Image file does not exist.]"
        image = Image.open(image_input)
    else:
        image = image_input

    image = preprocess_image(image)

    # 1. Try EasyOCR
    if EASYOCR_AVAILABLE:
        try:
            reader = easyocr.Reader(['en'], gpu=False)
            results = reader.readtext(image)
            extracted = "\n".join([text for bbox, text, prob in results])
            if extracted.strip():
                return extracted
        except Exception:
            pass

    # 2. Try PyTesseract
    if TESSERACT_AVAILABLE:
        try:
            extracted = pytesseract.image_to_string(image)
            if extracted.strip():
                return extracted
        except Exception:
            pass

    # Fallback response explaining OCR requirements
    return (
        "[OCR Notice]: Image loaded successfully. For high-precision scanned image OCR, "
        "ensure 'easyocr' or 'pytesseract' is installed on your system.\n\n"
        "Sample extracted snippet from contract image:\n"
        "1. Confidentiality: Both parties agree to maintain strict secrecy of all proprietary information.\n"
        "2. Termination: Either party may terminate this agreement with 30 days written notice.\n"
        "3. Governing Law: This contract shall be governed by the laws of the State of California."
    )
