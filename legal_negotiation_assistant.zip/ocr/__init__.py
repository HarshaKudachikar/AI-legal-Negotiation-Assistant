"""
OCR package initialization.
"""
from ocr.ocr_engine import extract_text_from_image
