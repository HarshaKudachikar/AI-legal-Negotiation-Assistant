# System Flowcharts - Legal Negotiation Assistant

## 1. User Authentication & Session Flowchart

```
[Start] --> [User Visits App] --> {Is Authenticated?}
                                         |
                       +-----------------+-----------------+
                       |                                   |
                     (No)                                (Yes)
                       |                                   |
         +-------------+-------------+           [Display Main Dashboard]
         |                           |                     |
   [Select Login]          [Select Register]               |
         |                           |                     |
 [Enter Credentials]       [Validate Inputs]              |
         |                           |                     |
  [Verify Hash]            [Save to SQLite DB]            |
         |                           |                     |
         +-------------+-------------+                     |
                       |                                   |
               [Set Session State] <-----------------------+
```

## 2. Document Processing & Risk Analysis Flowchart

```
[Upload Document (PDF/DOCX/Image)] 
             |
             v
[Detect File Type Extension]
             |
   +---------+---------+--------------------+
   |                   |                    |
(PDF)               (DOCX)              (IMAGE)
   |                   |                    |
[pdfplumber/PyPDF] [python-docx]       [OCR Scanner]
   |                   |                    |
   +---------+---------+--------------------+
             |
             v
[Extracted Text Buffer]
             |
             v
[Split Text into Clauses]
             |
             v
[Classify Clauses (11 Categories)]
             |
             v
[Evaluate Risk (Low / Medium / High)]
             |
             v
[Generate Plain English & Counter-Wording]
             |
             v
[Store Analysis in SQLite DB] --> [Display Interactive Audit Report]
```

## 3. Contract Comparison Flowchart

```
[Upload Version A (Original)] + [Upload Version B (Revised)]
             |
             v
[Extract Text A & Text B]
             |
             v
[SequenceMatcher Diff Algorithm]
             |
             v
[Identify Added, Removed, & Modified Clauses]
             |
             v
[Calculate Comparative Risk Score Shift]
             |
             v
[Render Side-by-Side Diff Table]
```
