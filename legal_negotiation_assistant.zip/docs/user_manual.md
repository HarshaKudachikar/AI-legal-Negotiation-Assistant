# User Manual - Legal Negotiation Assistant

Welcome to the **Legal Negotiation Assistant**, an educational AI platform designed to help users analyze, understand, and negotiate legal agreements with confidence.

---

## ⚠️ Important Educational Disclaimer

This application is strictly for educational, informational, and training purposes. It is **NOT a substitute for formal legal advice** from a licensed attorney.

---

## Getting Started

### 1. Account Creation & Login
- Launch the application by running `streamlit run app.py`.
- Click on **Register** in the sidebar to create a new account.
- Enter your username, email, and password.
- Switch to **Login** to enter your account dashboard.
- *Default Admin Credentials*: Username `admin` | Password `admin123`.

---

## Core Features Guide

### 2. Document Upload & Processing
- Navigate to the **Upload Document** tab.
- Drag & drop or select a PDF, DOCX, TXT, or Image file (JPG/PNG).
- Click **Analyze Contract**.
- The system extracts all text, splits it into clauses, and classifies risk levels automatically.

### 3. Dashboard Metrics & Visualizations
- View total documents analyzed, overall contract risk score, and high-risk flags.
- View interactive Plotly charts showing risk distribution and category breakdowns.

### 4. AI Document Analysis & Risk Audit
- View clauses highlighted by risk level:
  - 🔴 **High Risk**: Onerous provisions needing careful attention or negotiation.
  - 🟡 **Medium Risk**: Standard restrictions requiring clarification.
  - 🟢 **Low Risk**: Standard, balanced contractual terms.
- Read plain-English explanations and potential legal consequences for each clause.

### 5. Negotiation Assistant & Battlecards
- For each flagged clause, review:
  - **Neutral Questions**: Professional questions to ask the counterparty during discussions.
  - **Example Counter-Clause**: Sample alternative wording for educational reference.

### 6. AI Contract Q&A Chat
- Ask natural language questions in the **AI Chat** tab:
  - *"What happens if I terminate this contract early?"*
  - *"Does this agreement claim ownership of my side projects?"*
  - *"Explain the indemnity clause in simple terms."*

### 7. Clause Search
- Type any keyword (e.g., *"arbitration"*, *"late fee"*, *"non-compete"*) to instantly filter and highlight matching clauses across your document.

### 8. Contract Comparison (Version Diffing)
- Upload two contract versions (e.g., Original Draft vs Revised Counter-Offer).
- View side-by-side added, removed, and modified clauses with highlighted diffs.

### 9. Export PDF Reports
- Download a formatted PDF executive summary, risk report, or negotiation battlecard directly from the app.

### 10. Download Complete Project ZIP
- Click **Download Project ZIP** at any time to export the full source code and database archive.
