# Testing Guide - Legal Negotiation Assistant

This document outlines the test suite and validation procedures for verifying the functionality, accuracy, and reliability of the Legal Negotiation Assistant.

## Automated Test Execution

You can run automated unit & integration tests by creating a test script or using `pytest`.

### Test Suite Test Cases

1. **User Authentication Tests (`test_auth`)**:
   - Register new user -> Verify DB record insertion.
   - Duplicate username registration -> Verify rejection.
   - Login with correct password -> Verify authentication success.
   - Login with wrong password -> Verify access denied.

2. **Document Parsing Tests (`test_parser`)**:
   - Parse `.txt` sample document -> Verify raw text extraction.
   - Parse `.pdf` file -> Verify structural line retention.
   - Parse `.docx` file -> Verify paragraph extraction.

3. **Clause Extraction & Risk Engine Tests (`test_analyzer`)**:
   - Analyze 5-year Non-compete clause -> Expect **High Risk** rating & career mobility warnings.
   - Analyze 30-day Termination clause -> Expect **Low Risk** rating.
   - Verify all 11 categories (Non-compete, Indemnity, Liability, etc.) are correctly identified.

4. **Document Comparison Tests (`test_comparator`)**:
   - Compare Document A vs Document B -> Verify added, removed, and modified clause list.

5. **PDF Report Generation (`test_report`)**:
   - Call `generate_pdf_report()` -> Verify valid PDF binary bytes output.

---

## Manual UI Verification Checklist

- [x] Launch app: `streamlit run app.py`
- [x] Register user account & verify session login.
- [x] Upload sample contract `sample_docs/sample_employment_agreement.txt`.
- [x] Verify total clauses count and risk breakdown charts on Dashboard.
- [x] Open **AI Document Analysis** tab and inspect plain English translations.
- [x] Open **Negotiation Assistant** tab and review neutral questions & counter-clauses.
- [x] Test **AI Chat** with question: *"What are the main risks in this contract?"*
- [x] Test **Clause Search** keyword filter: *"Non-compete"*.
- [x] Test **Contract Comparison** by uploading two agreement versions.
- [x] Click **Download PDF Report** and confirm file opens cleanly.
- [x] Login as Admin (`admin` / `admin123`) and verify user/document management controls.
