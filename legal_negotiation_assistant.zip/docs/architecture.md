# System Architecture - Legal Negotiation Assistant

The **Legal Negotiation Assistant** is an end-to-end AI-powered document intelligence and negotiation platform.

## Architecture Overview Diagram

```
+-------------------------------------------------------------------------+
|                              STREAMLIT UI                               |
| (Authentication, Upload, Dashboard, Q&A Chat, Diff Tool, Admin Panel)   |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                             BACKEND ENGINE                              |
|                                                                         |
| +-------------------+  +-------------------+  +-----------------------+ |
| | Document Parser   |  | Clause Analyzer   |  | Negotiation Engine    | |
| | (PDF, DOCX, Img)  |  | (11 Categories)   |  | (Plain Eng, Counter)  | |
| +---------+---------+  +---------+---------+  +-----------+-----------+ |
|           |                      |                        |             |
|           +----------------------+------------------------+             |
|                                  |                                      |
+----------------------------------+--------------------------------------+
                                   |
           +-----------------------+-----------------------+
           |                                               |
           v                                               v
+-----------------------+                       +-----------------------+
|    AI & NLP STACK     |                       |    DATABASE & STORAGE |
| - SentenceTransformer |                       | - SQLite Storage      |
| - Zero-shot Rules     |                       | - User Passwords Hash |
| - Optional LLM APIs   |                       | - Documents & Audits  |
+-----------------------+                       +-----------------------+
```

## Component Breakdown

1. **Frontend Presentation Layer (`app.py`, `utils/helpers.py`)**:
   - Streamlit single-page application with sidebar tab navigation.
   - Dynamic dark theme styling with HSL gradients, metric cards, and responsive layouts.
   - Plotly interactive charts for risk breakdown and clause distribution.

2. **Parsing & OCR Layer (`backend/document_parser.py`, `ocr/ocr_engine.py`)**:
   - Multi-format ingestion supporting PDF, DOCX, TXT, JPG, PNG.
   - PyPDF & pdfplumber for structural PDF extraction.
   - EasyOCR / PyTesseract with image preprocessing for scanned document images.

3. **NLP & Risk Analysis Engine (`backend/clause_analyzer.py`)**:
   - Pattern matching + semantic heuristics across 11 key legal categories:
     *Termination, Payment, Confidentiality, Non-compete, Non-disclosure, Arbitration, Liability, Indemnity, Intellectual Property, Jurisdiction, Force Majeure*.
   - Quantitative risk scoring (0 - 100) assigning High, Medium, or Low severity.

4. **Negotiation Battlecard Generator (`backend/negotiation_engine.py`)**:
   - Translates legalese into plain English.
   - Generates neutral questions for counterparty negotiation.
   - Provides example alternative counter-clauses.

5. **Semantic Search & RAG Chat (`models/embeddings.py`, `models/llm_handler.py`)**:
   - Vector similarity using SentenceTransformers (`all-MiniLM-L6-v2`) or TF-IDF fallback.
   - Interactive Q&A chatbot using document context.

6. **Persistence & Export Layer (`database/db_manager.py`, `backend/report_generator.py`)**:
   - SQLite database storing users, password hashes (SHA-256), uploaded files, and analysis history.
   - PDF Audit Report generation via ReportLab.
