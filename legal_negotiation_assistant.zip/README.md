# ⚖️ Legal Negotiation Assistant

An advanced, production-ready AI-powered web application built with Python and Streamlit to analyze legal agreements, detect high-risk clauses, translate legalese into plain English, generate neutral negotiation questions, offer alternative counter-clauses, conduct RAG Q&A chat, compare contract versions, and export PDF audit reports.

> ⚠️ **EDUCATIONAL DISCLAIMER**: This application is strictly for educational, research, and self-learning purposes. It does **NOT** provide formal legal advice, legal opinions, or attorney-client representation. Always consult a qualified licensed attorney before signing binding legal agreements.

---

## 🌟 Key Features

1. **User Authentication & Authorization**:
   - Secure registration, login, PBKDF2/SHA-256 password hashing.
   - User roles (`user` vs `admin`) and SQLite database persistence.
2. **Multi-Format Ingestion & OCR**:
   - Accepts `.pdf`, `.docx`, `.txt`, and scanned document images (`.jpg`, `.png`).
   - PyPDF & pdfplumber for PDF layout extraction; EasyOCR & PyTesseract for image scanning.
3. **AI Clause Classification & Risk Engine**:
   - Detects 11 major clause categories: *Termination, Payment, Confidentiality, Non-compete, Non-disclosure, Arbitration, Liability, Indemnity, Intellectual Property, Jurisdiction, Force Majeure*.
   - Evaluates Risk Levels (**Low**, **Medium**, **High**) with detailed explanations and pre-signature checklists.
4. **Negotiation Battlecards**:
   - Plain-English translations of complex legalese.
   - Neutral non-confrontational questions to ask counterparties during contract discussions.
   - Example alternative counter-clauses.
5. **Contextual AI Chatbot (RAG)**:
   - Ask natural language questions about uploaded contracts.
6. **Semantic & Keyword Clause Search**:
   - Instant search across document clauses using SentenceTransformers or TF-IDF vector embeddings.
7. **Side-by-Side Contract Comparison (Diffing)**:
   - Compare two contract versions (e.g. Original vs Counter-offer) highlighting added, removed, and modified clauses.
8. **Plotly Dashboard & Analytics**:
   - Interactive risk score meters, pie charts, and clause distribution bar charts.
9. **Export PDF Reports**:
   - Executive summaries, risk audit reports, and negotiation battlecards exported via ReportLab.
10. **Admin Management Panel**:
    - Manage registered users, inspect document database, and delete entries.
11. **One-Click Downloadable ZIP**:
    - Export the complete application source code, models, and sample datasets into a `.zip` archive directly from the UI.

---

## 📂 Project Directory Structure

```
legal_negotiation_assistant/
├── app.py                     # Main Streamlit application entry point
├── requirements.txt           # Dependency list
├── README.md                  # Comprehensive README guide
├── export_project_zip.py      # Utility script to package project into legal_negotiation_assistant.zip
├── database/
│   ├── __init__.py
│   ├── db_manager.py          # SQLite schema, user/document/chat CRUD
├── backend/
│   ├── __init__.py
│   ├── auth.py                # Password hashing, registration, authentication
│   ├── document_parser.py     # PDF, DOCX, & Image text extraction
│   ├── clause_analyzer.py     # 11-category clause detection & Risk Engine
│   ├── negotiation_engine.py  # Plain English translator & counter-wording generator
│   ├── comparator.py          # Side-by-side contract diffing
│   └── report_generator.py   # PDF Report Generator
├── ocr/
│   ├── __init__.py
│   └── ocr_engine.py          # Image & scanned page OCR engine
├── models/
│   ├── __init__.py
│   ├── embeddings.py          # SentenceTransformer & vector search
│   └── llm_handler.py         # Configurable LLM API / Local Heuristics
├── utils/
│   ├── __init__.py
│   ├── helpers.py             # Streamlit CSS, Metric cards, Plotly charts
│   └── disclaimers.py         # Educational disclaimers
├── sample_docs/               # Pre-loaded test contracts
│   ├── sample_employment_agreement.txt
│   ├── sample_vendor_contract.txt
│   └── sample_nda_strict.txt
└── docs/                      # Capstone Documentation Deliverables
    ├── architecture.md        # System Architecture & Component Diagram
    ├── flowchart.md           # System & Data Flowcharts
    ├── testing_guide.md       # Test Suite & Verification Checklist
    └── user_manual.md         # Comprehensive User Manual
```

---

## 🚀 Quick Start Guide

### 1. Installation

Clone or extract the repository, navigate into the directory, and install dependencies:

```bash
cd legal_negotiation_assistant
pip install -r requirements.txt
```

### 2. Running the Application

Launch the Streamlit web application with a single command:

```bash
streamlit run app.py
```

Open your browser at `http://localhost:8501`.

---

## 🔑 Default Admin Account Credentials

- **Username**: `admin`
- **Password**: `admin123`

---

## 📊 Sample Datasets for Quick Testing

Three pre-loaded contracts are available under `sample_docs/` or directly in the UI:
1. `sample_employment_agreement.txt`: Features 5-year Non-compete, one-sided Indemnity, immediate Termination, and broad IP assignment.
2. `sample_vendor_contract.txt`: Features Payment terms, Limitation of Liability cap, Confidentiality, and Force Majeure.
3. `sample_nda_strict.txt`: Features Mutual Non-disclosure obligations, Exclusions, and Injunctive Relief.

---

## 📄 License & Legal Notice

Distributed under the MIT License. This tool is built strictly for educational purposes and capstone project demonstrations.
