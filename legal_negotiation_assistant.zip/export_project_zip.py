"""
Project Packaging Utility.
Creates a clean, production-ready legal_negotiation_assistant.zip archive
containing all source code, models, database schemas, documentation, and sample datasets.
"""

import os
import zipfile

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
ZIP_OUTPUT_PATH = os.path.join(PROJECT_DIR, "legal_negotiation_assistant.zip")

EXCLUDE_DIRS = {".git", "__pycache__", ".pytest_cache", ".idea", ".vscode", "venv", ".venv"}
EXCLUDE_EXTS = {".pyc", ".pyo", ".zip"}


def create_project_zip() -> str:
    """Pack all project files into a downloadable zip file."""
    with zipfile.ZipFile(ZIP_OUTPUT_PATH, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(PROJECT_DIR):
            # Exclude specified directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTS or file == "legal_negotiation_assistant.zip":
                    continue

                abs_filepath = os.path.join(root, file)
                rel_filepath = os.path.relpath(abs_filepath, PROJECT_DIR)
                zipf.write(abs_filepath, arcname=rel_filepath)

    return ZIP_OUTPUT_PATH


if __name__ == "__main__":
    path = create_project_zip()
    print(f"Project successfully zipped to: {path}")
