"""
Database package initialization.
"""
from database.db_manager import init_db

# Auto-initialize database schema on import
init_db()
