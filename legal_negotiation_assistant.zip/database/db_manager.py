"""
Database Manager for SQLite database storage.
Handles user authentication records, uploaded document metadata, analysis results, and system logs.
"""

import os
import sqlite3
import json
from datetime import datetime

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "legal_assistant.db")


def get_connection():
    """Establish and return a SQLite connection with dict factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialize database tables if they do not exist."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = get_connection()
    cursor = conn.cursor()

    # Users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Documents table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        file_type TEXT NOT NULL,
        upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        extracted_text TEXT NOT NULL,
        clause_count INTEGER DEFAULT 0,
        overall_risk_score REAL DEFAULT 0.0,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # Analyses table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doc_id INTEGER NOT NULL,
        summary TEXT,
        clauses_json TEXT,
        risk_breakdown_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (doc_id) REFERENCES documents (id) ON DELETE CASCADE
    )
    """)

    # Chat History table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doc_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        message TEXT NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (doc_id) REFERENCES documents (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    conn.commit()

    # Create default admin user if not exists
    cursor.execute("SELECT * FROM users WHERE username = 'admin'")
    if not cursor.fetchone():
        import hashlib
        # Hash 'admin123'
        salt = "legal_salt_2026"
        hashed = hashlib.sha256((salt + "admin123").encode('utf-8')).hexdigest()
        cursor.execute(
            "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)",
            ("admin", "admin@legalassistant.com", hashed, "admin")
        )
        conn.commit()

    conn.close()


# User CRUD Operations
def create_user(username, email, password_hash, role="user"):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)",
            (username, email, password_hash, role)
        )
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        return True, user_id
    except sqlite3.IntegrityError as e:
        conn.close()
        return False, str(e)


def get_user_by_username(username):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_users():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, email, role, created_at FROM users ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_user(user_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
    return True


# Document CRUD Operations
def save_document(user_id, filename, file_type, extracted_text, clause_count=0, risk_score=0.0):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO documents (user_id, filename, file_type, extracted_text, clause_count, overall_risk_score)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (user_id, filename, file_type, extracted_text, clause_count, risk_score)
    )
    conn.commit()
    doc_id = cursor.lastrowid
    conn.close()
    return doc_id


def save_analysis(doc_id, summary, clauses, risk_breakdown):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO analyses (doc_id, summary, clauses_json, risk_breakdown_json) VALUES (?, ?, ?, ?)",
        (doc_id, summary, json.dumps(clauses), json.dumps(risk_breakdown))
    )
    conn.commit()
    conn.close()


def get_user_documents(user_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM documents WHERE user_id = ? ORDER BY upload_time DESC", (user_id,)
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_documents():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """SELECT d.*, u.username 
           FROM documents d 
           JOIN users u ON d.user_id = u.id 
           ORDER BY d.upload_time DESC"""
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_document_by_id(doc_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM documents WHERE id = ?", (doc_id,))
    doc = cursor.fetchone()

    cursor.execute("SELECT * FROM analyses WHERE doc_id = ? ORDER BY created_at DESC LIMIT 1", (doc_id,))
    analysis = cursor.fetchone()
    conn.close()

    if not doc:
        return None

    res = dict(doc)
    if analysis:
        res["summary"] = analysis["summary"]
        res["clauses"] = json.loads(analysis["clauses_json"]) if analysis["clauses_json"] else []
        res["risk_breakdown"] = json.loads(analysis["risk_breakdown_json"]) if analysis["risk_breakdown_json"] else {}
    else:
        res["summary"] = ""
        res["clauses"] = []
        res["risk_breakdown"] = {}

    return res


def delete_document(doc_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    conn.commit()
    conn.close()
    return True


# Chat History
def save_chat_message(doc_id, user_id, role, message):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO chat_history (doc_id, user_id, role, message) VALUES (?, ?, ?, ?)",
        (doc_id, user_id, role, message)
    )
    conn.commit()
    conn.close()


def get_chat_history(doc_id, user_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT role, message, timestamp FROM chat_history WHERE doc_id = ? AND user_id = ? ORDER BY id ASC",
        (doc_id, user_id)
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
