"""
UI Helper functions and Custom Styling for Streamlit.
Renders professional theme cards, Plotly risk charts, risk badges, and modern CSS layout.
"""

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd


def inject_custom_css():
    """Inject modern CSS styles, card containers, and custom typography."""
    st.markdown("""
    <style>
    /* Main Layout Styling */
    .stApp {
        background-color: #0F172A;
        color: #F8FAFC;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }

    /* Header & Title Styling */
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    
    .sub-header {
        color: #94A3B8;
        font-size: 1rem;
        margin-bottom: 1.5rem;
    }

    /* Metric Cards */
    .metric-card {
        background: #1E293B;
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 1.25rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .metric-card:hover {
        border-color: #3B82F6;
        transform: translateY(-2px);
    }
    .metric-value {
        font-size: 2.2rem;
        font-weight: 800;
        color: #F8FAFC;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* Risk Badges */
    .badge-high {
        background-color: rgba(220, 38, 38, 0.2);
        color: #EF4444;
        border: 1px solid #EF4444;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .badge-medium {
        background-color: rgba(217, 119, 6, 0.2);
        color: #F59E0B;
        border: 1px solid #F59E0B;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .badge-low {
        background-color: rgba(22, 163, 74, 0.2);
        color: #10B981;
        border: 1px solid #10B981;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
    }

    /* Clause Container Card */
    .clause-card {
        background: #1E293B;
        border-left: 4px solid #3B82F6;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        margin-bottom: 1rem;
    }
    .clause-card-high {
        border-left-color: #EF4444;
        background: rgba(239, 68, 68, 0.05);
    }
    .clause-card-medium {
        border-left-color: #F59E0B;
        background: rgba(245, 158, 11, 0.05);
    }
    .clause-card-low {
        border-left-color: #10B981;
        background: rgba(16, 185, 129, 0.05);
    }

    /* Disclaimer Box */
    .disclaimer-box {
        background: rgba(245, 158, 11, 0.1);
        border: 1px solid #F59E0B;
        border-radius: 10px;
        padding: 1rem;
        margin-top: 1rem;
        color: #FCD34D;
        font-size: 0.9rem;
    }
    </style>
    """, unsafe_allow_html=True)


def render_metric_card(label: str, value: str, icon: str = "📄"):
    """Render a styled dashboard metric card."""
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size: 1.5rem; margin-bottom: 0.5rem;">{icon}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-label">{label}</div>
    </div>
    """, unsafe_allow_html=True)


def render_risk_pie_chart(risk_breakdown: dict):
    """Render Plotly Pie Chart for clause risk breakdown."""
    df = pd.DataFrame([
        {"Risk": "High Risk", "Count": risk_breakdown.get("High", 0), "Color": "#EF4444"},
        {"Risk": "Medium Risk", "Count": risk_breakdown.get("Medium", 0), "Color": "#F59E0B"},
        {"Risk": "Low Risk", "Count": risk_breakdown.get("Low", 0), "Color": "#10B981"}
    ])

    fig = px.pie(
        df,
        names="Risk",
        values="Count",
        color="Risk",
        color_discrete_map={
            "High Risk": "#EF4444",
            "Medium Risk": "#F59E0B",
            "Low Risk": "#10B981"
        },
        hole=0.4,
        title="Clause Risk Distribution"
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#F8FAFC"),
        margin=dict(t=40, b=20, l=20, r=20),
        showlegend=True
    )
    st.plotly_chart(fig, use_container_width=True)


def render_clause_category_bar_chart(clauses: list[dict]):
    """Render Plotly Bar Chart for clauses grouped by category."""
    if not clauses:
        return

    df = pd.DataFrame(clauses)
    category_counts = df["category"].value_counts().reset_index()
    category_counts.columns = ["Category", "Count"]

    fig = px.bar(
        category_counts,
        x="Count",
        y="Category",
        orientation="h",
        title="Detected Clause Categories",
        color="Count",
        color_continuous_scale="Blues"
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#F8FAFC"),
        xaxis=dict(gridcolor="#334155"),
        yaxis=dict(gridcolor="#334155"),
        margin=dict(t=40, b=20, l=20, r=20)
    )
    st.plotly_chart(fig, use_container_width=True)
