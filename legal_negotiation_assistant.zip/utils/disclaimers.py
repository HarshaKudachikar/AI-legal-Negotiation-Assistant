"""
Legal disclaimers and educational notices for the Legal Negotiation Assistant.
"""

LEGAL_DISCLAIMER_TEXT = """
⚠️ **IMPORTANT EDUCATIONAL DISCLAIMER**

The **Legal Negotiation Assistant** is an AI-powered educational tool designed solely to help users read, summarize, and understand legal contract language and potential negotiation points. 

- **NOT LEGAL ADVICE**: This tool, its risk ratings, explanations, and suggested alternative clause text DO NOT constitute formal legal advice, legal opinions, or attorney-client privilege.
- **NO GUARANTEE**: Contract laws vary significantly by jurisdiction, industry, and context. The suggestions provided here are for illustrative and educational reference only and may not be legally valid or enforceable in your jurisdiction.
- **CONSULT A QUALIFIED ATTORNEY**: Always consult a licensed attorney or legal professional before signing binding legal agreements, modifying legal contracts, or entering into formal business negotiations.
"""

SHORT_DISCLAIMER = "⚠️ Educational Tool Only: Not formal legal advice. Consult a licensed attorney before signing."
