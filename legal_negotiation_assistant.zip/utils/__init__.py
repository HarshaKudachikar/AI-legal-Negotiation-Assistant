"""
Utils package initialization.
"""
from utils.disclaimers import LEGAL_DISCLAIMER_TEXT, SHORT_DISCLAIMER
from utils.helpers import inject_custom_css, render_metric_card, render_risk_pie_chart, render_clause_category_bar_chart
