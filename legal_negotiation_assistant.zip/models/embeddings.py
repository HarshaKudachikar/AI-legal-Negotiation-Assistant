"""
Semantic Embeddings & Vector Search Module.
Uses SentenceTransformers (all-MiniLM-L6-v2) or scikit-learn TfidfVectorizer fallback
for clause semantic search and context retrieval.
"""

import numpy as np

SENTENCE_TRANSFORMERS_AVAILABLE = False
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    pass

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class SemanticSearchEngine:
    def __init__(self):
        self.model = None
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
            except Exception:
                self.model = None

    def get_embeddings(self, texts: list[str]) -> np.ndarray:
        """Compute embeddings for a list of text snippets."""
        if not texts:
            return np.array([])

        if self.model:
            try:
                return self.model.encode(texts, show_progress_bar=False)
            except Exception:
                pass

        # TF-IDF Fallback
        vectorizer = TfidfVectorizer(stop_words='english')
        try:
            tfidf_matrix = vectorizer.fit_transform(texts)
            return tfidf_matrix.toarray()
        except Exception:
            # Simple length matrix fallback
            return np.ones((len(texts), 10))

    def search_similar_clauses(self, query: str, clauses: list[dict], top_k: int = 5) -> list[dict]:
        """Search top_k clauses matching query semantically."""
        if not clauses:
            return []

        clause_texts = [c.get("text", "") for c in clauses]
        if self.model:
            try:
                query_vec = self.model.encode([query])
                clause_vecs = self.model.encode(clause_texts)
                scores = cosine_similarity(query_vec, clause_vecs)[0]

                # Pair score with clause
                ranked_indices = np.argsort(scores)[::-1]
                results = []
                for idx in ranked_indices[:top_k]:
                    item = dict(clauses[idx])
                    item["similarity_score"] = float(scores[idx])
                    results.append(item)
                return results
            except Exception:
                pass

        # TF-IDF Fallback search
        try:
            all_texts = [query] + clause_texts
            vectorizer = TfidfVectorizer(stop_words='english')
            tfidf_matrix = vectorizer.fit_transform(all_texts)
            scores = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

            ranked_indices = np.argsort(scores)[::-1]
            results = []
            for idx in ranked_indices[:top_k]:
                item = dict(clauses[idx])
                item["similarity_score"] = float(scores[idx])
                results.append(item)
            return results
        except Exception:
            # Keyword matching fallback
            query_terms = set(query.lower().split())
            results = []
            for c in clauses:
                text_terms = set(c.get("text", "").lower().split())
                overlap = len(query_terms.intersection(text_terms))
                item = dict(c)
                item["similarity_score"] = float(overlap / (len(query_terms) + 1e-5))
                results.append(item)
            results.sort(key=lambda x: x["similarity_score"], reverse=True)
            return results[:top_k]


# Global instance singleton
search_engine = SemanticSearchEngine()
