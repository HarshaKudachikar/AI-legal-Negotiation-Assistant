"""
LLM Handler Module.
Configurable AI provider supporting:
1. Rule-Based / NLP Local Heuristic Engine (Default zero-cost local execution)
2. Hugging Face Transformers local pipeline
3. OpenAI API (if API Key provided)
4. Ollama Local LLM (http://localhost:11434)
5. Google Gemini API (if API Key provided)
"""

import requests
from utils.disclaimers import SHORT_DISCLAIMER


class LLMHandler:
    def __init__(self, provider: str = "Local NLP Engine", api_key: str = "", model_name: str = "default"):
        self.provider = provider
        self.api_key = api_key
        self.model_name = model_name

    def ask_contract_question(self, question: str, document_text: str, clauses: list[dict]) -> str:
        """
        Answer user question based on document context.
        """
        q_lower = question.lower()

        # 1. OpenAI API Provider
        if self.provider == "OpenAI API" and self.api_key:
            try:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "model": self.model_name if self.model_name != "default" else "gpt-3.5-turbo",
                    "messages": [
                        {"role": "system", "content": "You are a legal document negotiation educational assistant. Answer questions clearly based on contract context."},
                        {"role": "user", "content": f"Document Text:\n{document_text[:4000]}\n\nQuestion: {question}"}
                    ]
                }
                res = requests.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers, timeout=15)
                if res.status_code == 200:
                    return res.json()["choices"][0]["message"]["content"]
            except Exception as e:
                pass

        # 2. Ollama Provider
        if self.provider == "Ollama (Local LLM)":
            try:
                payload = {
                    "model": self.model_name if self.model_name != "default" else "llama2",
                    "prompt": f"Contract Context:\n{document_text[:3000]}\n\nQuestion: {question}\nAnswer:",
                    "stream": False
                }
                res = requests.post("http://localhost:11434/api/generate", json=payload, timeout=10)
                if res.status_code == 200:
                    return res.json()["response"]
            except Exception:
                pass

        # 3. Default Local Heuristic RAG QA Engine
        # Find relevant clauses matching question
        relevant_clauses = []
        for c in clauses:
            cat = c.get("category", "").lower()
            txt = c.get("text", "").lower()
            if any(term in q_lower for term in [cat, "risk", "meaning", "explain", "negotiate", "what"]):
                if any(k in txt or k in cat for k in q_lower.split() if len(k) > 3):
                    relevant_clauses.append(c)

        if not relevant_clauses:
            relevant_clauses = clauses[:3]

        answer = f"**AI Document Assistant Response ({SHORT_DISCLAIMER}):**\n\n"

        if "risk" in q_lower:
            high_risks = [c for c in clauses if c.get("risk_level") == "High"]
            answer += f"• **High-Risk Flags**: Identified {len(high_risks)} high-risk clauses in this agreement.\n"
            for hr in high_risks[:3]:
                answer += f"  - **{hr.get('category')}**: {hr.get('reason')}\n"
        elif "negotiate" in q_lower or "negotiation" in q_lower:
            answer += "• **Suggested Negotiation Focus Areas**:\n"
            for c in clauses[:3]:
                answer += f"  - **{c.get('category')}**: Consider asking for mutual terms or capping liabilities.\n"
        else:
            answer += "• **Relevant Contract Findings**:\n"
            for rel in relevant_clauses[:2]:
                answer += f"  - **{rel.get('category')}** (Risk: {rel.get('risk_level')}): \"{rel.get('text')[:200]}...\"\n"
                answer += f"    *Explanation*: {rel.get('reason')}\n"

        answer += (
            "\n💡 *Tip: You can use the 'Clause Search' tab to inspect matching sections in full detail.*"
        )
        return answer
