"""
Clause Analyzer Module.
Detects major legal clauses across 11 key categories:
1. Termination
2. Payment
3. Confidentiality
4. Non-compete
5. Non-disclosure
6. Arbitration
7. Liability
8. Indemnity
9. Intellectual Property
10. Jurisdiction
11. Force Majeure

Evaluates risk levels (Low, Medium, High) with detailed explanations, potential legal consequences,
and pre-signature checklist points.
"""

import re

CLAUSE_PATTERNS = {
    "Non-compete": {
        "keywords": ["non-compete", "not compete", "competitor", "solicit clients", "covenant not to compete", "restrictive covenant"],
        "regex": r"(?:non-compete|shall not engage|shall not work for|competitor|solicit clients|5 years|3 years|2 years)"
    },
    "Indemnity": {
        "keywords": ["indemnify", "indemnification", "hold harmless", "defend and hold", "losses and damages"],
        "regex": r"(?:indemnify|hold harmless|defend against|losses, damages|claims arising out of)"
    },
    "Liability": {
        "keywords": ["limitation of liability", "cap on damages", "consequential damages", "maximum liability", "no liability"],
        "regex": r"(?:limitation of liability|in no event shall|aggregate liability|consequential damages|punitive damages)"
    },
    "Termination": {
        "keywords": ["termination", "terminate", "notice period", "termination for cause", "terminate immediately", "cure period"],
        "regex": r"(?:termination|terminate|cancel this agreement|written notice|without cause|immediate termination)"
    },
    "Payment": {
        "keywords": ["payment", "compensation", "fee", "invoicing", "late interest", "penalty", "due date", "remuneration"],
        "regex": r"(?:payment terms|compensation|invoices|late fee|interest rate|shall pay|due within)"
    },
    "Confidentiality": {
        "keywords": ["confidential", "confidentiality", "proprietary information", "trade secrets", "disclosure"],
        "regex": r"(?:confidential information|proprietary|trade secrets|keep strict secrecy|shall not disclose)"
    },
    "Non-disclosure": {
        "keywords": ["non-disclosure", "nda", "third parties", "disclose information", "receiving party"],
        "regex": r"(?:non-disclosure|third party|disclose to any person|receiving party|disclosing party)"
    },
    "Arbitration": {
        "keywords": ["arbitration", "binding arbitration", "arbitrator", "aaa rules", "class action waiver"],
        "regex": r"(?:binding arbitration|arbitrator|american arbitration association|waive right to jury|class action waiver)"
    },
    "Intellectual Property": {
        "keywords": ["intellectual property", "ip rights", "work for hire", "assignment of inventions", "patents", "copyrights"],
        "regex": r"(?:intellectual property|work made for hire|assigns all rights|ownership of IP|inventions)"
    },
    "Jurisdiction": {
        "keywords": ["governing law", "jurisdiction", "venue", "courts of", "choice of law"],
        "regex": r"(?:governing law|jurisdiction|venue|exclusive jurisdiction|state of|courts located in)"
    },
    "Force Majeure": {
        "keywords": ["force majeure", "act of god", "unforeseen events", "natural disaster", "epidemic"],
        "regex": r"(?:force majeure|act of god|natural disasters|war|beyond reasonable control)"
    }
}


def split_text_into_clauses(text: str) -> list[str]:
    """Split contract text into distinct paragraph clauses."""
    # Split by numbered sections or double line breaks
    raw_blocks = re.split(r'\n\s*\n|\n(?=[0-9]+\.|\([a-z]\)|SECTION|ARTICLE|Clause)', text)
    clauses = [b.strip() for b in raw_blocks if len(b.strip()) > 30]
    if not clauses and text.strip():
        # Fallback to sentence/line splitting if single paragraph
        clauses = [line.strip() for line in text.split('\n') if len(line.strip()) > 30]
    return clauses


def assess_clause_risk(category: str, text: str) -> dict:
    """
    Assess risk rating (Low, Medium, High) for a given clause text and category.
    Returns structured analysis dictionary.
    """
    text_lower = text.lower()

    risk_level = "Low"
    score = 25
    reason = "Standard contractual provision with balanced obligations."
    consequences = "Minimally burdensome to standard business or employment operations."
    understand_points = [
        "Ensure you understand basic timelines and obligation triggers.",
        "Keep records of all formal notices sent or received."
    ]

    if category == "Non-compete":
        # Check for harsh duration or broad geography
        if any(term in text_lower for term in ["5 years", "3 years", "worldwide", "global", "any competitor", "entire industry"]):
            risk_level = "High"
            score = 90
            reason = "Excessively broad post-employment non-compete duration or geographic restriction."
            consequences = "Could severely limit your career mobility, future job offers, or business operations for years."
            understand_points = [
                "Understand exactly which competitors you are prohibited from joining.",
                "Verify whether post-employment compensation is paid during the non-compete period.",
                "Check if local laws cap non-compete clauses (e.g., California renders most post-employment non-competes void)."
            ]
        else:
            risk_level = "Medium"
            score = 65
            reason = "Restricted covenant limiting competitive activities."
            consequences = "May prevent working directly with immediate project competitors."
            understand_points = [
                "Clarify the specific definition of 'competitor'.",
                "Ensure geographic scope is limited to your actual working location."
            ]

    elif category == "Indemnity":
        if any(term in text_lower for term in ["unlimited", "solely responsible", "all claims", "attorney fees", "regardless of negligence"]):
            risk_level = "High"
            score = 95
            reason = "Uncapped or one-sided indemnity requiring full financial defense of the counterparty."
            consequences = "Exposes you to catastrophic out-of-pocket legal expenses and damages even if you were not at fault."
            understand_points = [
                "Check if indemnity is mutual or strictly one-sided against you.",
                "Ensure your liability is capped by insurance coverage or a total monetary limit."
            ]
        else:
            risk_level = "Medium"
            score = 60
            reason = "Standard indemnification obligation."
            consequences = "Obligates reimbursement for direct losses caused by material breach."
            understand_points = ["Verify that indemnity applies only to third-party claims caused by your gross negligence."]

    elif category == "Liability":
        if any(term in text_lower for term in ["no liability", "waive all damages", "disclaims all warranties", "unlimited liability"]):
            risk_level = "High"
            score = 85
            reason = "One-sided limitation of liability disclaiming counterparty liability while leaving your liability uncapped."
            consequences = "You may have no financial recourse if the vendor/employer fails to deliver or breaches terms."
            understand_points = [
                "Insist on mutual liability caps (e.g., capped at total fees paid in 12 months).",
                " Carve out gross negligence and willful misconduct from liability waivers."
            ]
        else:
            risk_level = "Medium"
            score = 55
            reason = "Standard limitation of liability clause."
            consequences = "Caps financial recovery in disputes to specified threshold."
            understand_points = ["Ensure the liability limit matches total contract value."]

    elif category == "Termination":
        if any(term in text_lower for term in ["without cause", "immediate termination", "no notice", "penalty fee"]):
            risk_level = "High"
            score = 80
            reason = "Allows immediate termination without prior notice or cure period, or imposes termination fees."
            consequences = "Counterparty can cancel contract without notice, leaving you abruptly without revenue or employment."
            understand_points = [
                "Request a minimum 30-day written notice requirement.",
                "Include a 15-to-30 day 'cure period' to resolve minor alleged defaults before termination."
            ]
        else:
            risk_level = "Low"
            score = 30
            reason = "Standard termination clause with reasonable notice period."
            consequences = "Provides clear timeline for ending contract relations."
            understand_points = ["Confirm notice period requirements and delivery methods."]

    elif category == "Arbitration":
        if "waive right" in text_lower or "class action waiver" in text_lower or "sole discretion" in text_lower:
            risk_level = "High"
            score = 75
            reason = "Mandatory binding arbitration with jury trial and class action waivers."
            consequences = "Deprives you of public court trial rights and restricts joint claim filings."
            understand_points = [
                "Check who pays arbitration fees (arbitration can be more expensive than court).",
                "Ensure arbitration location is convenient to your home state/city."
            ]
        else:
            risk_level = "Medium"
            score = 50
            reason = "Alternative dispute resolution requirement."
            consequences = "Disputes resolved privately via neutral arbitrator rather than public court."
            understand_points = ["Verify rules governing arbitrator selection."]

    elif category == "Intellectual Property":
        if any(term in text_lower for term in ["all prior work", "personal inventions", "assigns all", "perpetual"]):
            risk_level = "High"
            score = 85
            reason = "Overbroad IP assignment potentially capturing your pre-existing IP, personal projects, or open-source work."
            consequences = "You risk losing ownership of side projects or pre-existing tools developed prior to contract execution."
            understand_points = [
                "Explicitly carve out prior inventions and personal open-source projects in an exhibit.",
                "Ensure IP assignment applies strictly to work created specifically for this client/employer."
            ]
        else:
            risk_level = "Low"
            score = 35
            reason = "Work-for-hire assignment limited to deliverables created under contract."
            consequences = "Transfers ownership of commissioned deliverables upon full payment."
            understand_points = ["Ensure IP transfer is conditioned upon receipt of full payment."]

    elif category == "Jurisdiction":
        if any(term in text_lower for term in ["foreign", "remote state", "delaware", "england", "london"]):
            risk_level = "Medium"
            score = 60
            reason = "Governing law set in a foreign state or distant jurisdiction."
            consequences = "Increases legal costs if litigation occurs due to remote travel and local legal counsel fees."
            understand_points = ["Propose changing venue/governing law to your home location or neutral jurisdiction."]
        else:
            risk_level = "Low"
            score = 20
            reason = "Standard governing law selection."
            consequences = "Establishes clear legal framework in case of disputes."
            understand_points = ["Confirm familiar state law governs interpretation."]

    return {
        "risk_level": risk_level,
        "risk_score": score,
        "reason": reason,
        "consequences": consequences,
        "understand_points": understand_points
    }


def analyze_document_clauses(full_text: str) -> tuple[list[dict], dict, str, float]:
    """
    Analyzes document text, categorizes clauses, rates risks, and produces summary.
    Returns:
        clauses (list of dicts)
        risk_breakdown (dict count of High, Medium, Low)
        document_summary (str)
        overall_risk_score (float)
    """
    raw_clauses = split_text_into_clauses(full_text)
    detected_clauses = []
    seen_texts = set()

    for idx, block in enumerate(raw_clauses):
        block_clean = block.strip()
        if block_clean in seen_texts:
            continue

        matched_category = None
        for cat, data in CLAUSE_PATTERNS.items():
            # Check keywords or regex matches
            if any(kw in block_clean.lower() for kw in data["keywords"]) or re.search(data["regex"], block_clean, re.IGNORECASE):
                matched_category = cat
                break

        if not matched_category:
            # Check for generic risk markers
            if any(kw in block_clean.lower() for kw in ["shall not", "penalty", "liable", "breach", "damages", "forfeit"]):
                matched_category = "General Obligation"

        if matched_category:
            seen_texts.add(block_clean)
            assessment = assess_clause_risk(matched_category, block_clean)
            detected_clauses.append({
                "id": len(detected_clauses) + 1,
                "category": matched_category,
                "text": block_clean,
                "risk_level": assessment["risk_level"],
                "risk_score": assessment["risk_score"],
                "reason": assessment["reason"],
                "consequences": assessment["consequences"],
                "understand_points": assessment["understand_points"]
            })

    # If no clauses matched specific patterns, extract key paragraphs as general provisions
    if not detected_clauses:
        for idx, block in enumerate(raw_clauses[:5]):
            detected_clauses.append({
                "id": idx + 1,
                "category": "General Provision",
                "text": block,
                "risk_level": "Low",
                "risk_score": 25,
                "reason": "General contract terms and conditions.",
                "consequences": "Standard contractual commitment.",
                "understand_points": ["Review terms carefully with legal counsel."]
            })

    # Risk breakdown calculation
    risk_counts = {"High": 0, "Medium": 0, "Low": 0}
    total_score = 0
    for c in detected_clauses:
        risk_counts[c["risk_level"]] += 1
        total_score += c["risk_score"]

    overall_score = round(total_score / len(detected_clauses), 1) if detected_clauses else 0.0

    # Summary Generation
    doc_summary = (
        f"Document Analysis Summary:\n"
        f"• Total Clauses Identified: {len(detected_clauses)}\n"
        f"• High Risk Clauses: {risk_counts['High']}\n"
        f"• Medium Risk Clauses: {risk_counts['Medium']}\n"
        f"• Low Risk Clauses: {risk_counts['Low']}\n"
        f"• Overall Document Risk Rating: {'HIGH' if overall_score > 70 else 'MEDIUM' if overall_score > 40 else 'LOW'} ({overall_score}/100)\n\n"
        f"Key Attention Areas: " +
        (", ".join([c["category"] for c in detected_clauses if c["risk_level"] == "High"]) or "No high risk clauses flagged.")
    )

    return detected_clauses, risk_counts, doc_summary, overall_score
