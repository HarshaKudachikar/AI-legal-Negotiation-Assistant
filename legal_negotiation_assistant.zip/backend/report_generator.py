"""
Report Generator Module.
Generates professional PDF reports (PDF summary, Negotiation Battlecards, Risk Audit Reports).
Uses ReportLab with HTML/text fallback if ReportLab is missing.
"""

import io
from datetime import datetime

REPORTLAB_AVAILABLE = False
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    REPORTLAB_AVAILABLE = True
except ImportError:
    pass

from utils.disclaimers import LEGAL_DISCLAIMER_TEXT


def generate_pdf_report(doc_data: dict, report_type: str = "FULL") -> bytes:
    """
    Generate PDF report for a document analysis.
    report_type: 'SUMMARY', 'RISK', or 'FULL'
    Returns PDF file bytes.
    """
    filename = doc_data.get("filename", "Contract")
    extracted_text = doc_data.get("extracted_text", "")
    summary = doc_data.get("summary", "")
    clauses = doc_data.get("clauses", [])
    risk_breakdown = doc_data.get("risk_breakdown", {"High": 0, "Medium": 0, "Low": 0})
    risk_score = doc_data.get("overall_risk_score", 0.0)

    if not REPORTLAB_AVAILABLE:
        # Fallback text buffer formatted as PDF downloadable text
        output = io.StringIO()
        output.write("=====================================================\n")
        output.write("         LEGAL NEGOTIATION ASSISTANT REPORT           \n")
        output.write("             (EDUCATIONAL USE ONLY)                   \n")
        output.write("=====================================================\n\n")
        output.write(f"Document: {filename}\n")
        output.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        output.write(f"Overall Risk Score: {risk_score}/100\n\n")
        output.write("--- EXECUTIVE SUMMARY ---\n")
        output.write(f"{summary}\n\n")
        output.write("--- CLAUSE RISK AUDIT & NEGOTIATION POINTS ---\n\n")
        for c in clauses:
            output.write(f"Clause #{c.get('id')} [{c.get('category')}] - RISK: {c.get('risk_level')}\n")
            output.write(f"Text: {c.get('text')}\n")
            output.write(f"Reason: {c.get('reason')}\n")
            output.write(f"Consequences: {c.get('consequences')}\n")
            output.write("Understand Points:\n")
            for p in c.get('understand_points', []):
                output.write(f"  • {p}\n")
            output.write("\n" + "-"*50 + "\n\n")

        output.write(LEGAL_DISCLAIMER_TEXT + "\n")
        return output.getvalue().encode('utf-8')

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E293B'),
        spaceAfter=10
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontSize=10,
        textColor=colors.HexColor('#64748B'),
        spaceAfter=15
    )
    heading2_style = ParagraphStyle(
        'Heading2Custom',
        parent=styles['Heading2'],
        fontSize=14,
        leading=18,
        textColor=colors.HexColor('#0F172A'),
        spaceBefore=12,
        spaceAfter=8
    )
    body_style = ParagraphStyle(
        'BodyCustom',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#334155'),
        spaceAfter=8
    )
    high_risk_style = ParagraphStyle(
        'HighRisk',
        parent=body_style,
        textColor=colors.HexColor('#DC2626')
    )

    story = []

    # Title Banner
    story.append(Paragraph("Legal Negotiation Assistant - Audit Report", title_style))
    story.append(Paragraph(f"Document: <b>{filename}</b> | Generated: {datetime.now().strftime('%B %d, %Y')}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563EB'), spaceAfter=15))

    # Risk Metrics Table
    risk_color = colors.HexColor('#DC2626') if risk_score > 70 else colors.HexColor('#D97706') if risk_score > 40 else colors.HexColor('#16A34A')
    data_metrics = [
        ["Overall Risk Score", f"{risk_score} / 100"],
        ["High Risk Clauses", str(risk_breakdown.get("High", 0))],
        ["Medium Risk Clauses", str(risk_breakdown.get("Medium", 0))],
        ["Low Risk Clauses", str(risk_breakdown.get("Low", 0))]
    ]
    t = Table(data_metrics, colWidths=[200, 300])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#F1F5F9')),
        ('TEXTCOLOR', (0,0), (-1,-1), colors.HexColor('#0F172A')),
        ('FONTNAME', (0,0), (-1,-1), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
    ]))
    story.append(t)
    story.append(Spacer(1, 15))

    # Executive Summary
    story.append(Paragraph("Executive Summary", heading2_style))
    story.append(Paragraph(summary.replace('\n', '<br/>'), body_style))
    story.append(Spacer(1, 15))

    # Detailed Clauses
    story.append(Paragraph("Detailed Clause & Risk Analysis", heading2_style))

    for c in clauses:
        risk_lvl = c.get("risk_level", "Low")
        bg_col = "#FEF2F2" if risk_lvl == "High" else "#FFFBEB" if risk_lvl == "Medium" else "#F0FDF4"
        text_col = "#991B1B" if risk_lvl == "High" else "#92400E" if risk_lvl == "Medium" else "#166534"

        story.append(Paragraph(f"<b>Clause #{c.get('id')} - {c.get('category')}</b> (Risk Level: <font color='{text_col}'><b>{risk_lvl}</b></font>)", body_style))
        story.append(Paragraph(f"<i>Text:</i> \"{c.get('text')}\"", body_style))
        story.append(Paragraph(f"<b>Reason for Rating:</b> {c.get('reason')}", body_style))
        story.append(Paragraph(f"<b>Potential Consequences:</b> {c.get('consequences')}", body_style))

        understand = c.get("understand_points", [])
        if understand:
            pts_str = "<br/>".join([f"• {pt}" for pt in understand])
            story.append(Paragraph(f"<b>Key points to understand:</b><br/>{pts_str}", body_style))

        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#E2E8F0'), spaceBefore=8, spaceAfter=8))

    story.append(Spacer(1, 15))
    story.append(Paragraph("<b>Educational Disclaimer</b>", heading2_style))
    story.append(Paragraph(LEGAL_DISCLAIMER_TEXT.replace('\n', '<br/>'), body_style))

    doc.build(story)
    return buffer.getvalue()
