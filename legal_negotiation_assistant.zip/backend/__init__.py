"""
Backend package initialization.
"""
from backend.auth import authenticate_user, register_user
from backend.document_parser import parse_document
from backend.clause_analyzer import analyze_document_clauses
from backend.negotiation_engine import get_clause_negotiation_package
from backend.comparator import compare_documents
from backend.report_generator import generate_pdf_report
