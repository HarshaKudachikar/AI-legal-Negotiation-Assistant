"""
User authentication and password management module.
Provides secure password hashing, registration validation, and login verification.
"""

import hashlib
import re
from database.db_manager import create_user, get_user_by_username

SALT = "legal_salt_2026"


def hash_password(password: str) -> str:
    """Hash password using SHA-256 with fixed salt for security."""
    return hashlib.sha256((SALT + password).encode('utf-8')).hexdigest()


def validate_user_registration(username, email, password):
    """Validate username, email format, and password strength."""
    if not username or len(username.strip()) < 3:
        return False, "Username must be at least 3 characters long."

    email_regex = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    if not re.match(email_regex, email):
        return False, "Invalid email address format."

    if not password or len(password) < 6:
        return False, "Password must be at least 6 characters long."

    return True, ""


def register_user(username, email, password, role="user"):
    """Register a new user in the database."""
    valid, err_msg = validate_user_registration(username, email, password)
    if not valid:
        return False, err_msg

    pwd_hash = hash_password(password)
    success, msg = create_user(username.strip(), email.strip().lower(), pwd_hash, role)
    if not success:
        if "username" in str(msg).lower():
            return False, "Username already exists. Please choose another."
        elif "email" in str(msg).lower():
            return False, "Email already registered. Please login or use another email."
        return False, f"Registration failed: {msg}"

    return True, "User registered successfully!"


def authenticate_user(username, password):
    """Authenticate user credentials and return user object if valid."""
    user = get_user_by_username(username.strip())
    if not user:
        return None, "Invalid username or password."

    pwd_hash = hash_password(password)
    if user["password_hash"] != pwd_hash:
        return None, "Invalid username or password."

    return user, "Login successful!"
