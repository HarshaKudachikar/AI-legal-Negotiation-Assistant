"""
Document Parser module.
Handles extraction of raw text from PDF, DOCX, TXT, and Image files (JPG, PNG).
Preserves structural headings, paragraphs, and lists.
"""

import io
import os
from PIL import Image

# PDF Libraries
PYPDF_AVAILABLE = False
PDFPLUMBER_AVAILABLE = False
DOCX_AVAILABLE = False

try:
    import pypdf
    PYPDF_AVAILABLE = True
except ImportError:
    pass

try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    pass

try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    pass

from ocr.ocr_engine import extract_text_from_image


def parse_pdf(file_bytes_or_path) -> str:
    """Extract text from PDF using pdfplumber or pypdf."""
    extracted_text = ""

    # Try pdfplumber first for superior layout preservation
    if PDFPLUMBER_AVAILABLE:
        try:
            if isinstance(file_bytes_or_path, bytes):
                with pdfplumber.open(io.BytesIO(file_bytes_or_path)) as pdf:
                    for page in pdf.pages:
                        text = page.extract_text()
                        if text:
                            extracted_text += text + "\n\n"
            else:
                with pdfplumber.open(file_bytes_or_path) as pdf:
                    for page in pdf.pages:
                        text = page.extract_text()
                        if text:
                            extracted_text += text + "\n\n"
            if extracted_text.strip():
                return extracted_text.strip()
        except Exception:
            pass

    # Fallback to PyPDF
    if PYPDF_AVAILABLE:
        try:
            if isinstance(file_bytes_or_path, bytes):
                reader = pypdf.PdfReader(io.BytesIO(file_bytes_or_path))
            else:
                reader = pypdf.PdfReader(file_bytes_or_path)

            for page in reader.pages:
                text = page.extract_text()
                if text:
                    extracted_text += text + "\n\n"
            if extracted_text.strip():
                return extracted_text.strip()
        except Exception:
            pass

    return extracted_text.strip() if extracted_text else "[Error: Could not extract text from PDF file.]"


def parse_docx(file_bytes_or_path) -> str:
    """Extract text from DOCX document using python-docx."""
    if not DOCX_AVAILABLE:
        return "[Error: 'python-docx' library is missing. Install with 'pip install python-docx'.]"

    try:
        if isinstance(file_bytes_or_path, bytes):
            doc = docx.Document(io.BytesIO(file_bytes_or_path))
        else:
            doc = docx.Document(file_bytes_or_path)

        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        return "\n\n".join(paragraphs)
    except Exception as e:
        return f"[Error parsing DOCX file: {str(e)}]"


def parse_image(file_bytes_or_path) -> str:
    """Extract text from image file using OCR engine."""
    try:
        if isinstance(file_bytes_or_path, bytes):
            image = Image.open(io.BytesIO(file_bytes_or_path))
        else:
            image = Image.open(file_bytes_or_path)
        return extract_text_from_image(image)
    except Exception as e:
        return f"[Error parsing image file: {str(e)}]"


def parse_document(file_name: str, file_content) -> tuple[str, str]:
    """
    Master file parser dispatcher.
    Returns tuple: (extracted_text, file_type)
    """
    ext = os.path.splitext(file_name)[1].lower()

    if ext == ".pdf":
        text = parse_pdf(file_content)
        file_type = "PDF"
    elif ext in [".docx", ".doc"]:
        text = parse_docx(file_content)
        file_type = "DOCX"
    elif ext in [".jpg", ".jpeg", ".png", ".bmp"]:
        text = parse_image(file_content)
        file_type = "IMAGE"
    elif ext in [".txt", ".md"]:
        if isinstance(file_content, bytes):
            text = file_content.decode("utf-8", errors="ignore")
        else:
            with open(file_content, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        file_type = "TXT"
    else:
        text = "[Error: Unsupported file format.]"
        file_type = "UNKNOWN"

    return text, file_type
