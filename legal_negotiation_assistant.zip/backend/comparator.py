"""
Document Comparator Module.
Compares two versions of a legal contract (Original vs Revised) to detect:
- Added clauses
- Removed clauses
- Modified clauses
- Risk metric changes
"""

import difflib
from backend.clause_analyzer import split_text_into_clauses, analyze_document_clauses


def compare_documents(original_text: str, revised_text: str) -> dict:
    """
    Compare original contract text against revised text.
    Returns categorized changes and comparative risk analysis.
    """
    orig_clauses = split_text_into_clauses(original_text)
    rev_clauses = split_text_into_clauses(revised_text)

    # Analyze individual documents for risk metrics
    orig_analyzed, orig_breakdown, _, orig_score = analyze_document_clauses(original_text)
    rev_analyzed, rev_breakdown, _, rev_score = analyze_document_clauses(revised_text)

    matcher = difflib.SequenceMatcher(None, orig_clauses, rev_clauses)

    added = []
    removed = []
    modified = []
    unchanged = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            for idx in range(i1, i2):
                unchanged.append(orig_clauses[idx])
        elif tag == 'replace':
            for idx1, idx2 in zip(range(i1, i2), range(j1, j2)):
                modified.append({
                    "original": orig_clauses[idx1],
                    "revised": rev_clauses[idx2],
                    "diff": "".join(difflib.ndiff([orig_clauses[idx1]], [rev_clauses[idx2]]))
                })
            # Handle unequal lengths
            if (i2 - i1) > (j2 - j1):
                for idx in range(i1 + (j2 - j1), i2):
                    removed.append(orig_clauses[idx])
            elif (j2 - j1) > (i2 - i1):
                for idx in range(j1 + (i2 - i1), j2):
                    added.append(rev_clauses[idx])
        elif tag == 'delete':
            for idx in range(i1, i2):
                removed.append(orig_clauses[idx])
        elif tag == 'insert':
            for idx in range(j1, j2):
                added.append(rev_clauses[idx])

    risk_diff = round(rev_score - orig_score, 1)

    summary = (
        f"Contract Version Comparison Summary:\n"
        f"• Added Clauses: {len(added)}\n"
        f"• Removed Clauses: {len(removed)}\n"
        f"• Modified Clauses: {len(modified)}\n"
        f"• Unchanged Clauses: {len(unchanged)}\n"
        f"• Original Risk Score: {orig_score}/100 -> Revised Risk Score: {rev_score}/100 "
        f"({'Increased Risk 📈' if risk_diff > 0 else 'Decreased Risk 📉' if risk_diff < 0 else 'Unchanged Risk ⚖️'})\n"
    )

    return {
        "summary": summary,
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged": unchanged,
        "original_risk_score": orig_score,
        "revised_risk_score": rev_score,
        "risk_diff": risk_diff,
        "orig_breakdown": orig_breakdown,
        "rev_breakdown": rev_breakdown
    }
