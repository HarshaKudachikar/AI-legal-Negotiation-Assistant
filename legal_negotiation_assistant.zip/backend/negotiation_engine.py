"""
Negotiation Assistant Engine.
Translates legal jargon into plain English, formulates neutral questions to ask counterparties,
and generates example alternative clause text for educational negotiation purposes.
"""

from utils.disclaimers import LEGAL_DISCLAIMER_TEXT, SHORT_DISCLAIMER


def translate_to_plain_english(clause_category: str, clause_text: str) -> str:
    """Translate complex legalese into clear, simple English."""
    category = clause_category.lower()

    if "non-compete" in category:
        return (
            "Plain English: This clause forbids you from working for competing companies "
            "or starting a business in the same industry for a specified timeframe after leaving."
        )
    elif "indemnity" in category:
        return (
            "Plain English: This means you promise to cover all legal costs, court fees, "
            "and compensation payments if a third party sues the other company because of your work or actions."
        )
    elif "liability" in category:
        return (
            "Plain English: This sets caps or limits on how much money either party can win in court "
            "if someone breaks the contract or causes financial damage."
        )
    elif "termination" in category:
        return (
            "Plain English: This defines how and when either party can cancel the contract, "
            "how much advance notice is required, and any associated cancellation penalties."
        )
    elif "arbitration" in category:
        return (
            "Plain English: Instead of resolving disputes in a public court with a judge or jury, "
            "you agree to settle arguments behind closed doors with a private arbitrator whose decision is final."
        )
    elif "intellectual property" in category or "ip" in category:
        return (
            "Plain English: This states who owns the work, designs, software, or inventions created "
            "during the contract, and whether pre-existing ideas remain your property."
        )
    elif "payment" in category:
        return (
            "Plain English: This specifies when payments are due, how invoices are calculated, "
            "and penalties or interest rates applied if payment is late."
        )
    elif "confidentiality" in category or "nda" in category:
        return (
            "Plain English: You agree to keep private company details, secrets, and documents "
            "strictly secret and not share them with outsiders."
        )
    elif "jurisdiction" in category:
        return (
            "Plain English: If a legal dispute arises, this selects which state or court system "
            "will handle the case and interpret the rules."
        )
    elif "force majeure" in category:
        return (
            "Plain English: Excuses parties from contractual obligations if extreme, uncontrollable "
            "events occur (such as natural disasters, war, or severe acts of god)."
        )
    else:
        return f"Plain English: This provision outlines specific rules and obligations regarding {clause_category}."


def generate_neutral_questions(clause_category: str, risk_level: str) -> list[str]:
    """Generate professional, non-confrontational questions for negotiation discussion."""
    category = clause_category.lower()

    if "non-compete" in category:
        return [
            "Could we clarify and narrow the exact list of primary direct competitors covered by this restriction?",
            "Can we reduce the post-employment non-compete duration from the current period down to 6 or 12 months?",
            "Will the company provide financial compensation or severance payout during the active non-compete timeframe?"
        ]
    elif "indemnity" in category:
        return [
            "Could we make this indemnification clause mutual so both parties are protected equally?",
            "Can we cap the maximum indemnity obligation to match our active commercial liability insurance coverage limit?",
            "Can we clarify that indemnification applies only to direct third-party claims resulting from gross negligence or intentional misconduct?"
        ]
    elif "liability" in category:
        return [
            "Can we establish a mutual liability cap equal to the total fees paid under this agreement over the preceding 12 months?",
            "Could we explicitly exclude routine breach of contract from uncapped liability damages?"
        ]
    elif "termination" in category:
        return [
            "Could we add a standard 30-day written notice period for termination without cause?",
            "Can we include a 15-day written notice and cure period prior to terminating for alleged breach?"
        ]
    elif "arbitration" in category:
        return [
            "Could we allow small claims court actions as an alternative option before resorting to formal arbitration?",
            "Can we confirm that arbitration costs will be split equally between both parties?"
        ]
    elif "intellectual property" in category:
        return [
            "Can we explicitly attach an Exhibit listing my pre-existing personal intellectual property and prior inventions?",
            "Could we clarify that ownership rights transfer only upon receipt of full and final payment?"
        ]
    else:
        return [
            f"Could you explain the practical business rationale behind this specific {clause_category} clause?",
            "Is there room to align this language with standard, balanced industry norms?",
            "Could we add a mutual protection provision to ensure equal balance for both sides?"
        ]


def generate_alternative_wording(clause_category: str, original_text: str) -> str:
    """Generate example balanced counter-wording for educational reference."""
    category = clause_category.lower()

    if "non-compete" in category:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            "\"During the term of this Agreement and for a period of six (6) months thereafter, "
            "Employee/Contractor shall not directly perform services for Named Primary Competitors "
            "[Exhibit A] within a 25-mile radius of Primary Office, provided Company pays 50% of base salary during such period.\""
        )
    elif "indemnity" in category:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            "\"Each party ('Indemnifying Party') agrees to defend and indemnify the other party against third-party claims, "
            "losses, and reasonable legal fees solely to the extent caused by Indemnifying Party's gross negligence, "
            "willful misconduct, or material breach of this Agreement, capped at the liability limit set forth herein.\""
        )
    elif "liability" in category:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            "\"Except for breaches of confidentiality or gross negligence, neither party's total cumulative aggregate liability "
            "under this Agreement shall exceed the total amount paid or payable by Client to Contractor under this Agreement in the 12 months preceding the claim.\""
        )
    elif "termination" in category:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            "\"Either party may terminate this Agreement without cause upon providing thirty (30) days prior written notice. "
            "In the event of a material breach, the non-breaching party shall provide written notice and a fifteen (15) day period to cure such breach.\""
        )
    elif "intellectual property" in category:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            "\"Contractor hereby assigns to Client all right, title, and interest in Work Deliverables created specifically for Client under this Agreement, "
            "effective upon Contractor's receipt of full payment. Contractor retains sole ownership of pre-existing tools, code, and IP.\""
        )
    else:
        return (
            "EXAMPLE BALANCED COUNTER-CLAUSE (FOR EDUCATIONAL REFERENCE ONLY):\n"
            f"\"The parties agree that all provisions relating to {clause_category} shall be interpreted mutually, in good faith, "
            "and in compliance with applicable state laws, ensuring equal protection and reasonable notice for both parties.\""
        )


def get_clause_negotiation_package(clause: dict) -> dict:
    """Generate a complete negotiation battlecard for a detected clause."""
    category = clause.get("category", "General")
    text = clause.get("text", "")
    risk = clause.get("risk_level", "Low")

    plain_english = translate_to_plain_english(category, text)
    questions = generate_neutral_questions(category, risk)
    alt_wording = generate_alternative_wording(category, text)

    return {
        "clause_id": clause.get("id"),
        "category": category,
        "original_text": text,
        "risk_level": risk,
        "plain_english": plain_english,
        "questions": questions,
        "alternative_wording": alt_wording,
        "disclaimer": SHORT_DISCLAIMER
    }
