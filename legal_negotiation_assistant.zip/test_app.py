"""
Automated Test & Verification Suite for Legal Negotiation Assistant.
Tests DB initialization, User Authentication, Document Parsing, Clause Analysis,
Negotiation Engine, Contract Comparison, PDF Export, and Project Packaging.
"""

import os
import sys

# Ensure project directory is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))



from database.db_manager import init_db, get_user_by_username, get_user_documents, delete_user
from backend.auth import register_user, authenticate_user
from backend.document_parser import parse_document
from backend.clause_analyzer import analyze_document_clauses
from backend.negotiation_engine import get_clause_negotiation_package
from backend.comparator import compare_documents
from backend.report_generator import generate_pdf_report
from export_project_zip import create_project_zip


def run_tests():
    print("==================================================")
    print(" RUNNING LEGAL NEGOTIATION ASSISTANT TEST SUITE ")
    print("==================================================")

    # 1. Test DB Init & Admin User
    init_db()
    admin_user = get_user_by_username("admin")
    assert admin_user is not None, "Admin user creation failed!"
    print("[OK] 1. Database schema and default admin user initialized successfully.")

    # 2. Test User Registration & Authentication
    test_user = "test_lawyer_2026"
    test_email = "test@legalassistant.com"
    test_pass = "securepass123"

    reg_ok, reg_msg = register_user(test_user, test_email, test_pass)
    assert reg_ok, f"User registration failed: {reg_msg}"

    auth_user, auth_msg = authenticate_user(test_user, test_pass)
    assert auth_user is not None, "Authentication failed!"
    assert auth_user["username"] == test_user
    print("[OK] 2. User registration and authentication tests passed.")

    # 3. Test Sample Document Parsing & Clause Analysis
    sample_path = os.path.join(os.path.dirname(__file__), "sample_docs", "sample_employment_agreement.txt")
    assert os.path.exists(sample_path), "Sample employment agreement file missing!"

    with open(sample_path, "r", encoding="utf-8") as f:
        sample_text = f.read()

    clauses, risk_breakdown, summary, overall_score = analyze_document_clauses(sample_text)
    assert len(clauses) > 0, "No clauses detected in sample agreement!"
    assert risk_breakdown["High"] > 0, "High risk non-compete clause failed to trigger High Risk rating!"
    print(f"[OK] 3. Clause Analysis passed! Extracted {len(clauses)} clauses (Overall Risk Score: {overall_score}/100).")

    # 4. Test Negotiation Engine
    high_risk_clause = next(c for c in clauses if c["risk_level"] == "High")
    pkg = get_clause_negotiation_package(high_risk_clause)
    assert "plain_english" in pkg and "questions" in pkg and "alternative_wording" in pkg
    print("[OK] 4. Negotiation Battlecard generator passed.")

    # 5. Test Document Comparison
    sample_b_path = os.path.join(os.path.dirname(__file__), "sample_docs", "sample_vendor_contract.txt")
    with open(sample_b_path, "r", encoding="utf-8") as f:
        sample_b_text = f.read()

    comp_res = compare_documents(sample_text, sample_b_text)
    assert "summary" in comp_res and "modified" in comp_res
    print("[OK] 5. Contract comparison and diffing passed.")

    # 6. Test PDF Report Generation
    doc_data = {
        "filename": "sample_employment_agreement.txt",
        "extracted_text": sample_text,
        "summary": summary,
        "clauses": clauses,
        "risk_breakdown": risk_breakdown,
        "overall_risk_score": overall_score
    }
    pdf_bytes = generate_pdf_report(doc_data)
    assert isinstance(pdf_bytes, bytes) and len(pdf_bytes) > 100
    print(f"[OK] 6. PDF Report Generator passed! Generated {len(pdf_bytes)} bytes PDF.")

    # 7. Test Project Packaging ZIP
    zip_output = create_project_zip()
    assert os.path.exists(zip_output), "ZIP packaging failed!"
    print(f"[OK] 7. Project Zipping passed! Created ZIP package: {zip_output}")

    # Cleanup test user
    delete_user(auth_user["id"])
    print("[OK] 8. Test user cleaned up.")

    print("\n==================================================")
    print(" ALL TEST CASES PASSED SUCCESSFULLY (100% OK) ")
    print("==================================================")



if __name__ == "__main__":
    run_tests()
